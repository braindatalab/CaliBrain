"""
.. _tut-visualization:

Visualization Tutorial
======================

TBC.

"""