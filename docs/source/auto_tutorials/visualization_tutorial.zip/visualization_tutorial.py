"""
.. _tut-visualization:

Visualization Tutorial
======================

This tutorial demonstrates how to use the visualization features of CaliBrain.

"""