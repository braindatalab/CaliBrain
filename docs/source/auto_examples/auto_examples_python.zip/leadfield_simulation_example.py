"""
.. _example-leadfield_simulation:

============================
Leadfield Matrix Simulation
============================

This example demonstrates how to simulate leadfield matrices using CaliBrain's
LeadfieldBuilder component.

The script shows how to:
- Load configuration from YAML files
- Set up logging for the simulation pipeline
- Initialize and run leadfield matrix computation
- Handle command-line arguments for flexible execution

This is useful for setting up forward models in EEG/MEG source localization.
"""

import argparse
from mne.datasets import sample
from calibrain.utils import load_config
import logging
from pathlib import Path
from calibrain import LeadfieldBuilder

# TEST

###############################################################################
# Configuration and Setup
# ------------------------
# First, we set up the argument parser and load the configuration file.

# def main(args=None):
#     # Set up argument parser
#     parser = argparse.ArgumentParser(description="Run the Leadfield simulation pipeline.")
#     parser.add_argument(
#         "--config",
#         type=str,
#         required=True,
#         help="Path to the YAML configuration file of leadfield simulation."
#     )
#     parser.add_argument(
#         "--log-level",
#         type=str,
#         choices=["NOTSET", "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
#         help="Set the logging level. Overrides the value in the configuration file."
#     )

    # Parse arguments (use provided args if given, otherwise use sys.argv)
    # args = parser.parse_args(args)
    # config = load_config(Path(args.config))

    ###########################################################################
    # Logging Setup
    # -------------
    # Configure logging level and format for the simulation pipeline.
    
    # Determine log level
    # valid_log_levels = ["NOTSET", "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
    # log_level = args.log_level or config.get("log_level", "INFO").upper()
    # if log_level not in valid_log_levels:
    #     print(f"Invalid log level '{log_level}' in configuration. Defaulting to 'INFO'.")
    #     log_level = "INFO"

    # Configure logging
    # logging.basicConfig(level=getattr(logging, log_level), format="%(asctime)s - %(levelname)s - %(message)s")
    # logger = logging.getLogger(__name__)
    # logger.info(f"Using configuration file: {Path(args.config)}")

    ###########################################################################
    # Leadfield Simulation
    # --------------------
    # Initialize the LeadfieldBuilder and run the simulation pipeline.
    
    # Initialize simulation
    # leadfield_sim = LeadfieldBuilder(config=config, logger=logger)

    # Run the pipeline
    # try:
    #     leadfield = leadfield_sim.simulate()
    #     logger.info(f"Leadfield shape: {leadfield.shape}")
    #     print(f"Leadfield simulation completed successfully!")
    #     print(f"   Shape: {leadfield.shape}")
    #     return leadfield
    # except Exception as e:
    #     logger.error(f"An error occurred during the pipeline execution: {e}")
    #     raise SystemExit(1)

###############################################################################
# Run the Example
# ---------------
# Execute the leadfield simulation with predefined configuration.

# if __name__ == "__main__":
#     # Run with example configuration
#     main([
#         "--config", "configs/leadfield_sim_cfg.yml",
#         "--log-level", "INFO"
#     ])